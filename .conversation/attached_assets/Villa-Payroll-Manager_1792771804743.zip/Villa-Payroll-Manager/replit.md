# Awadallah Hotels & Villas

A bilingual villa-booking and monthly payroll app that keeps attendance, bonuses, deductions, and net payouts separate by month.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/villa-payroll-manager run typecheck` — check the app's TypeScript
- `pnpm --filter @workspace/villa-payroll-manager run test` — run payroll model tests
- `PORT=4173 BASE_PATH=/ pnpm --filter @workspace/villa-payroll-manager run build` — create a production build
- `PORT=5173 BASE_PATH=/ pnpm --filter @workspace/villa-payroll-manager run dev` — run the app locally
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/villa-payroll-manager/` — the user-facing booking and payroll app
- `artifacts/villa-payroll-manager/README.md` — local run, check, and backup/restore instructions
- `artifacts/api-server/` and `lib/db/` — shared workspace scaffolding; the payroll app does not currently use them

## Architecture decisions

- The app stores its records in browser local storage and offers JSON backup/restore; it does not sync data between browsers or devices.
- Payroll is stored as independent `YYYY-MM` snapshots. Editing one month's attendance or adjustments must never change another month.
- Net payout is prorated base salary (`baseSalary × attendedDays / scheduledDays`, capped at 100%) plus bonus minus deductions.
- Do not present browser-local data as authenticated or server-backed payroll storage.

## Product

- Manage villa bookings and prevent overlapping reservations for the same room.
- Manage staff payroll by month, with historical attendance, bonuses, deductions, and calculated net payouts.
- Switch between Arabic and English.

## User preferences

- Preserve each month's payroll history when a new month is entered; provide a month selector.
- Include clear instructions and checks for running and testing the project.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
